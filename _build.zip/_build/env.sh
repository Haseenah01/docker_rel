export SECRET_KEY_BASE=HGF1ekWu4VWXZDLby40lUOJFN2dufDptrfr3C1NwwvZFeWmFYxSvUIFTc9/A/Gt/
export DATABASE_URL=ecto://postgres:postgres@10.0.9.100/docker_rel_dev

# mix ecto.create
# prod/rel/docker_rel/bin/migrate
prod/rel/docker_rel/bin/docker_rel eval "DockerRel.Release.migrate"
prod/rel/docker_rel/bin/docker_rel start_iex